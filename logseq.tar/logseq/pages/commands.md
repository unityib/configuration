- head
- tail
- cut
- Skip to main content
- cp - to copy somehting 
  id:: 66d26a6d-6ac1-4e50-8c21-0c4bf751aa4b
- grep
-
- ## commands for networking
  id:: 66df358b-4172-4a7f-8d4e-ccc76857a381
	-
-
- ss -tupln: to show all the ports used by apps at the moment
  collapsed:: true
	- ### examples:
		- `0.0.0.0:22`: accepts connections on any interface, port 22 for IPv4 connections only.
		- `[::]:22`: accepts connections on any interface, port 22 for IPv6 connections only.
	-
- netstat -tupln: same as ss -tupln
  id:: 66df3608-5bd5-40dd-91d1-891c08aae76e
- nmap: <ip address> <-flasgs>
  id:: 66df36b7-7f2e-4a9b-b20c-731360e3b20f
	- -h: Print a help summary page
	- -sS: Perform a TCP SYN scan
	- -sU: Perform a UDP scan
	- -sV: Probe open ports to determine service/version info
	- -O: Enable OS detection
	- -v: Enable verbosity. You can even set the verbosity level as such :
		- -vv: Level 2 verbosity. The minimum level of verbosity advised for use.
		- -v3: Level 3 verbosity. You can always specify the verbosity level by specifying a number like this.
	- -oA: Same Nmap output in “normal”, XML and grepable formats. However you can specify the format of your choice with :
		- -oN: Redirect normal output to a given filename
		- -oX: Produce output in a clean, XML format and store it in a given file
		- -oG: Produce “grepable” output and store it to a file. Deprecated format as users are now moving towards XML outputs.
	- -A: Enables “aggressive” scanning. Presently this enables OS 
	  detection (-O), version scanning (-sV), script scanning (-sC) and 
	  traceroute (–traceroute)
	- -p: Specify the ports to scan. It can be a single port as well as a range of ports. For Example :
		- `nmap -p 80 127.0.0.0.1`: This scans port 80 on localhost
		- `nmap -p 1-100 127.0.0.1`: This scans ports from 1 to 100 on localhost
		- `nmap -p- 127.0.0.1`: This scans all the ports on the localhost
	-
-
-